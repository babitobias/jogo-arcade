import { describe, expect, it } from "vitest";
import { CUBO_ARESTAS, avancarCiclo, cuboVertices, girarX, girarY, projetar } from "../../src/core/cena3d.js";

const camera = { x: 0, y: 0, z: 0, cx: 50, cy: 40, foco: 100 };

describe("projetar", () => {
  it("coloca no centro um ponto no eixo da câmera", () => {
    const p = projetar({ x: 0, y: 0, z: 10 }, camera);
    expect(p.visivel).toBe(true);
    expect(p.x).toBe(50);
    expect(p.y).toBe(40);
    expect(p.escala).toBe(10);
  });
  it("desloca para a direita pontos com x positivo", () => {
    expect(projetar({ x: 1, y: 0, z: 10 }, camera).x).toBe(60);
  });
  it("desenha para cima pontos com y positivo", () => {
    expect(projetar({ x: 0, y: 1, z: 10 }, camera).y).toBe(30);
  });
  it("aumenta a escala de pontos mais próximos", () => {
    expect(projetar({ x: 0, y: 0, z: 5 }, camera).escala).toBeGreaterThan(projetar({ x: 0, y: 0, z: 20 }, camera).escala);
  });
  it("descarta pontos atrás da câmera", () => {
    expect(projetar({ x: 0, y: 0, z: -3 }, camera).visivel).toBe(false);
  });
  it("acompanha o deslocamento da câmera (paralaxe)", () => {
    const p = projetar({ x: 0, y: 0, z: 10 }, { ...camera, x: 1 });
    expect(p.x).toBe(40);
  });
});

describe("rotações", () => {
  it("girarY de 90° leva +x para -z", () => {
    const p = girarY({ x: 1, y: 0, z: 0 }, Math.PI / 2);
    expect(p.x).toBeCloseTo(0);
    expect(p.z).toBeCloseTo(-1);
  });
  it("girarX de 90° leva +y para +z", () => {
    const p = girarX({ x: 0, y: 1, z: 0 }, Math.PI / 2);
    expect(p.y).toBeCloseTo(0);
    expect(p.z).toBeCloseTo(1);
  });
  it("preserva a distância até a origem", () => {
    const p = girarX(girarY({ x: 1, y: 2, z: 3 }, 0.7), 1.3);
    expect(Math.hypot(p.x, p.y, p.z)).toBeCloseTo(Math.hypot(1, 2, 3));
  });
});

describe("avancarCiclo", () => {
  it("dá a volta ao passar do máximo", () => expect(avancarCiclo(9, 2, 0, 10)).toBe(1));
  it("dá a volta ao passar do mínimo", () => expect(avancarCiclo(1, -2, 0, 10)).toBe(9));
  it("mantém valores dentro da faixa", () => expect(avancarCiclo(5, 3, 0, 10)).toBe(8));
});

describe("cubo", () => {
  it("tem 8 vértices", () => expect(cuboVertices(2)).toHaveLength(8));
  it("tem 12 arestas ligando vértices que diferem em uma coordenada", () => {
    const v = cuboVertices(2);
    expect(CUBO_ARESTAS).toHaveLength(12);
    for (const [a, b] of CUBO_ARESTAS) {
      const iguais = ["x", "y", "z"].filter((eixo) => v[a][eixo] === v[b][eixo]).length;
      expect(iguais).toBe(2);
    }
  });
});
