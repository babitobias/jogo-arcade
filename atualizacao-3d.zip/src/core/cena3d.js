// Matemática 3D pura (sem DOM): projeção em perspectiva, rotações e ciclos.
// A câmera olha para +z. Pontos com z menor que o da câmera não são visíveis.

/** camera = { x, y, z, cx, cy, foco } (cx, cy = centro da tela; foco = distância focal em px). */
export function projetar(ponto, camera) {
  const dz = ponto.z - camera.z;
  if (dz <= 0.05) return { visivel: false, x: 0, y: 0, escala: 0 };
  const escala = camera.foco / dz;
  return {
    visivel: true,
    x: camera.cx + (ponto.x - camera.x) * escala,
    y: camera.cy - (ponto.y - camera.y) * escala,
    escala,
  };
}

/** Gira o ponto em torno do eixo Y (ângulo em radianos). */
export function girarY(p, ang) {
  const c = Math.cos(ang);
  const s = Math.sin(ang);
  return { x: p.x * c + p.z * s, y: p.y, z: -p.x * s + p.z * c };
}

/** Gira o ponto em torno do eixo X (ângulo em radianos). */
export function girarX(p, ang) {
  const c = Math.cos(ang);
  const s = Math.sin(ang);
  return { x: p.x, y: p.y * c - p.z * s, z: p.y * s + p.z * c };
}

/** Mantém o valor dentro de [min, max), dando a volta nas pontas (movimento infinito). */
export function avancarCiclo(valor, delta, min, max) {
  const faixa = max - min;
  return ((((valor + delta - min) % faixa) + faixa) % faixa) + min;
}

/** Os 8 vértices de um cubo centrado na origem. */
export function cuboVertices(lado) {
  const m = lado / 2;
  const vertices = [];
  for (const x of [-m, m]) for (const y of [-m, m]) for (const z of [-m, m]) vertices.push({ x, y, z });
  return vertices;
}

/** Pares de índices (de cuboVertices) que formam as 12 arestas do cubo. */
export const CUBO_ARESTAS = (() => {
  const arestas = [];
  for (let a = 0; a < 8; a++) {
    for (let b = a + 1; b < 8; b++) {
      const diferentes = (a ^ b).toString(2).replace(/0/g, "").length;
      if (diferentes === 1) arestas.push([a, b]);
    }
  }
  return arestas;
})();
