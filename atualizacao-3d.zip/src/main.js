import conteudo from "./content/levels.json";
import { exigirConteudoValido } from "./core/content.js";
import { iniciarFundo3D } from "./scenes/fundo3d.js";
import { iniciar } from "./scenes/tela.js";

// __VERSAO__ e __SHA__ são substituídos no build (esbuild define).
const versao = `${__VERSAO__}+${__SHA__}`;
const canvas = document.getElementById("fundo3d");
if (canvas) iniciarFundo3D(canvas);
iniciar(document.getElementById("app"), exigirConteudoValido(conteudo), versao);
