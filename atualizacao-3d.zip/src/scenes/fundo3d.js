// Fundo 3D "synthwave" em canvas 2D: sol, estrelas, chão em grade e cubos girando,
// tudo com projeção em perspectiva real (src/core/cena3d.js). Sem bibliotecas.
import { CUBO_ARESTAS, avancarCiclo, cuboVertices, girarX, girarY, projetar } from "../core/cena3d.js";

const ALTURA_CHAO = -1.2;
const ESPACO_LINHAS = 2.4;
const VELOCIDADE_CHAO = 3.2;

const CUBOS = [
  { x: -6, y: 2.2, z: 14, lado: 2.2, cor: "0, 229, 255", giro: 0.7 },
  { x: 7.5, y: 3.4, z: 19, lado: 3.2, cor: "255, 46, 151", giro: -0.5 },
  { x: -12, y: 5, z: 26, lado: 3.6, cor: "255, 209, 102", giro: 0.4 },
  { x: 4, y: 1.4, z: 10, lado: 1.3, cor: "170, 130, 255", giro: -0.9 },
];

export function iniciarFundo3D(canvas) {
  const ctx = canvas.getContext("2d");
  if (!ctx) return () => {};
  const reduzirMovimento = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  let largura = 0;
  let altura = 0;
  let tempo = 0;
  let ultimo = 0;
  let quadro = 0;
  let paralaxe = 0;
  let alvoParalaxe = 0;

  const estrelas = Array.from({ length: 140 }, () => ({
    x: (Math.random() * 2 - 1) * 40,
    y: Math.random() * 18 + 1.5,
    z: Math.random() * 60 + 4,
    fase: Math.random() * 10,
  }));

  function ajustar() {
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    largura = window.innerWidth;
    altura = window.innerHeight;
    canvas.width = Math.round(largura * dpr);
    canvas.height = Math.round(altura * dpr);
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    if (reduzirMovimento) desenhar();
  }

  function criarCamera() {
    return { x: paralaxe * 1.4, y: 0, z: 0, cx: largura / 2, cy: altura * 0.5, foco: Math.max(largura, altura) * 0.8 };
  }

  function desenharSol(cam) {
    const raio = Math.min(largura, altura) * 0.24;
    const centroY = cam.cy - raio * 0.3;
    ctx.save();
    ctx.beginPath();
    ctx.rect(0, 0, largura, cam.cy);
    ctx.clip();
    const grad = ctx.createLinearGradient(0, centroY - raio, 0, centroY + raio);
    grad.addColorStop(0, "#ffd166");
    grad.addColorStop(1, "#ff2e97");
    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.arc(cam.cx, centroY, raio, 0, Math.PI * 2);
    ctx.fill();
    ctx.globalCompositeOperation = "destination-out"; // fendas do sol
    for (let k = 0; k < 6; k++) {
      ctx.fillRect(cam.cx - raio, centroY + raio * (0.05 + k * 0.16), raio * 2, 2 + k * 2.2);
    }
    ctx.restore();
  }

  function desenharChao(cam) {
    const grad = ctx.createLinearGradient(0, cam.cy, 0, altura);
    grad.addColorStop(0, "rgba(74, 18, 96, 0.65)");
    grad.addColorStop(1, "rgba(7, 1, 15, 0.96)");
    ctx.fillStyle = grad;
    ctx.fillRect(0, cam.cy, largura, altura - cam.cy);

    ctx.lineCap = "round";
    // linhas que vêm em direção à câmera (z constante)
    const deslocamento = (tempo * VELOCIDADE_CHAO) % ESPACO_LINHAS;
    for (let i = 0; i < 24; i++) {
      const z = 1.1 + i * ESPACO_LINHAS - deslocamento;
      const a = projetar({ x: -70, y: ALTURA_CHAO, z }, cam);
      const b = projetar({ x: 70, y: ALTURA_CHAO, z }, cam);
      if (!a.visivel) continue;
      ctx.strokeStyle = `rgba(255, 46, 151, ${Math.max(0.05, 0.8 - z / 62)})`;
      ctx.lineWidth = Math.max(0.6, a.escala * 0.02);
      ctx.beginPath();
      ctx.moveTo(a.x, a.y);
      ctx.lineTo(b.x, b.y);
      ctx.stroke();
    }
    // linhas que fogem para o horizonte (x constante), traçadas em um único caminho
    ctx.beginPath();
    for (let x = -40; x <= 40; x += 2.5) {
      const perto = projetar({ x, y: ALTURA_CHAO, z: 0.6 }, cam);
      const longe = projetar({ x, y: ALTURA_CHAO, z: 70 }, cam);
      ctx.moveTo(perto.x, perto.y);
      ctx.lineTo(longe.x, longe.y);
    }
    ctx.strokeStyle = "rgba(255, 46, 151, 0.1)";
    ctx.lineWidth = 5;
    ctx.stroke();
    ctx.strokeStyle = "rgba(255, 90, 180, 0.6)";
    ctx.lineWidth = 1.1;
    ctx.stroke();
  }

  function desenharEstrelas(cam, dt) {
    for (const e of estrelas) {
      e.z = avancarCiclo(e.z, -dt * 0.9, 3, 64);
      const p = projetar(e, cam);
      if (!p.visivel || p.y > cam.cy - 2 || p.x < 0 || p.x > largura) continue;
      const tam = Math.min(2.4, Math.max(0.6, p.escala * 0.035));
      const brilho = 0.35 + 0.65 * Math.abs(Math.sin(tempo * 1.5 + e.fase));
      ctx.fillStyle = `rgba(255, 255, 255, ${brilho})`;
      ctx.fillRect(p.x, p.y, tam, tam);
    }
  }

  function desenharCubos(cam) {
    const base = cuboVertices(1);
    CUBOS.forEach((c, i) => {
      const ay = tempo * c.giro + i;
      const ax = tempo * c.giro * 0.6 + i * 2;
      const flutuar = Math.sin(tempo * 0.8 + i * 1.7) * 0.35;
      const pontos = base.map((v) => {
        const g = girarX(girarY({ x: v.x * c.lado, y: v.y * c.lado, z: v.z * c.lado }, ay), ax);
        return projetar({ x: g.x + c.x, y: g.y + c.y + flutuar, z: g.z + c.z }, cam);
      });
      if (pontos.some((p) => !p.visivel)) return;
      ctx.beginPath();
      for (const [a, b] of CUBO_ARESTAS) {
        ctx.moveTo(pontos[a].x, pontos[a].y);
        ctx.lineTo(pontos[b].x, pontos[b].y);
      }
      ctx.strokeStyle = `rgba(${c.cor}, 0.18)`;
      ctx.lineWidth = 7;
      ctx.stroke();
      ctx.strokeStyle = `rgba(${c.cor}, 0.9)`;
      ctx.lineWidth = 1.6;
      ctx.stroke();
    });
  }

  function desenhar(dt = 0) {
    ctx.clearRect(0, 0, largura, altura);
    const cam = criarCamera();
    desenharSol(cam);
    desenharChao(cam);
    desenharEstrelas(cam, dt);
    desenharCubos(cam);
  }

  function passo(agora) {
    const dt = Math.min((agora - ultimo) / 1000, 0.05);
    ultimo = agora;
    tempo += dt;
    paralaxe += (alvoParalaxe - paralaxe) * 0.05;
    desenhar(dt);
    quadro = requestAnimationFrame(passo);
  }

  function iniciar() {
    ultimo = performance.now();
    quadro = requestAnimationFrame(passo);
  }

  function aoMover(e) {
    alvoParalaxe = (e.clientX / Math.max(largura, 1) - 0.5) * 2;
  }

  function aoMudarVisibilidade() {
    cancelAnimationFrame(quadro);
    if (!document.hidden) iniciar();
  }

  ajustar();
  window.addEventListener("resize", ajustar);
  if (reduzirMovimento) {
    desenhar();
  } else {
    window.addEventListener("mousemove", aoMover);
    document.addEventListener("visibilitychange", aoMudarVisibilidade);
    iniciar();
  }

  return function parar() {
    cancelAnimationFrame(quadro);
    window.removeEventListener("resize", ajustar);
    window.removeEventListener("mousemove", aoMover);
    document.removeEventListener("visibilitychange", aoMudarVisibilidade);
  };
}
